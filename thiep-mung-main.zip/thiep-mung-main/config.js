const nameGirl = 'Thảo';
const giftUrl = 'http://nodemy.vn';
const eventName = 'Chúc Mừng 8-3';
const titleCard = 'Tặng người ấy';
const contentCard = 'Chúc mừng ngày 8/3! Chúc bạn luôn xinh đẹp, rạng rỡ và tràn đầy hạnh phúc. Mong rằng mỗi ngày đều mang đến niềm vui, yêu thương và những điều tốt đẹp nhất. Bạn là một bông hoa đặc biệt, luôn tỏa sáng theo cách riêng của mình. Hãy tận hưởng ngày đặc biệt này với thật nhiều nụ cười và yêu thương!';

// phần dưới dành cho các bạn biết code, nếu muốn chỉnh ảnh đơn giản với base64
// Cần hỗ trợ hãy liên hệ: 
// Mr-Nam http://facebook.com/nam.nodemy
// Các bạn muốn học lập trình thì tham gia Nhóm zalo tự học lập trình nhé: https://zalo.me/g/yhdkef092
const giftImage = 'https://i.imgur.com/m3EgGC3.jpeg';
const base64 = '';
const giftImageBase64 = "data:image/png;base64, " + base64;
